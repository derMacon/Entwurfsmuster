package headfirst.strategy;

public class FliegtMitFluegeln implements FlugVerhalten {
	public void fliegen() {
		System.out.println("Ich fliege!!");
	}
}
