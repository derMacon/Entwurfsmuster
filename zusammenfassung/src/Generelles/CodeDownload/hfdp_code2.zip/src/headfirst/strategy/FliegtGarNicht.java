package headfirst.strategy;

public class FliegtGarNicht implements FlugVerhalten {
	public void fliegen() {
		System.out.println("Ich kann nicht fliegen.");
	}
}
