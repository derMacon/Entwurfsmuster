package headfirst.strategy;

public class VorgetaeuschtesQuaken implements QuakVerhalten {
	public void quaken() {
		System.out.println("Quark");
	}
}
