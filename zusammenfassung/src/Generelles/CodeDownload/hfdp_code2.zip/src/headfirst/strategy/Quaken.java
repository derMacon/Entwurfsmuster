package headfirst.strategy;

public class Quaken implements QuakVerhalten {
	public void quaken() {
		System.out.println("Quack");
	}
}
