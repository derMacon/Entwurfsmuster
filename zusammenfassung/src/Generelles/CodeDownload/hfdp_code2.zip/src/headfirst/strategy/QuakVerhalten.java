package headfirst.strategy;

public interface QuakVerhalten {
	public void quaken();
}
