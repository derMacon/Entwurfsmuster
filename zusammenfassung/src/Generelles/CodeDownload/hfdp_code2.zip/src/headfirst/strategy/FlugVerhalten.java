package headfirst.strategy;

public interface FlugVerhalten {
	public void fliegen();
}
