package headfirst.strategy;

public class FliegtRaketenGetrieben implements FlugVerhalten {
	public void fliegen() {
		System.out.println("Ich fliege mit Raketenantrieb!");
	}
}
