package headfirst.strategy;

public class StummesQuaken implements QuakVerhalten {
	public void quaken() {
		System.out.println("<< Stille >>");
	}
}
