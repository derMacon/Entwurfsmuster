package headfirst.command.fernsteuerung;

public class KeinBefehl implements Befehl {
	public void ausf�hren() { }
}
