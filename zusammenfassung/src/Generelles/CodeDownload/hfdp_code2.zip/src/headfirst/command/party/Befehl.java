package headfirst.command.party;

public interface Befehl {
	public void ausf�hren();
	public void r�ckg�ngig();
}
