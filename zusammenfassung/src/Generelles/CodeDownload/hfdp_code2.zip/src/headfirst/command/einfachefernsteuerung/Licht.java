package headfirst.command.einfachefernsteuerung;

public class Licht {

	public Licht() {
	}

	public void ein() {
		System.out.println("Das Licht ist an");
	}

	public void aus() {
		System.out.println("Das Licht ist aus");
	}
}
