package headfirst.command.rueckgaengig;

public class KeinBefehl implements Befehl {
	public void ausf�hren() { }
	public void r�ckg�ngig() { }
}
