package headfirst.command.party;

public class KeinBefehl implements Befehl {
	public void ausf�hren() { }
	public void r�ckg�ngig() { }
}
