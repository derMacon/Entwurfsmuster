package headfirst.command.einfachefernsteuerung;

public interface Befehl {
	public void ausf�hren();
}
