package headfirst.command.fernsteuerung;

public interface Befehl {
	public void ausf�hren();
}
