package headfirst.templatemethod.schulung;

public class Tee extends KoffeinhaltigesGetraenk {
	public void aufsch�tten() {
		System.out.println("Lasse Tee ziehen");
	}
	public void zutatenHinzuf�gen() {
		System.out.println("F�ge Zitrone hinzu");
	}
}
