package headfirst.combined.djview;
  
public interface BPMBeobachter {
	void aktualisiereBPM();
}
