package headfirst.combined.djview;
  
public interface BeatBeobachter {
	void aktualisiereBeat();
}
