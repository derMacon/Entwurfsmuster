package headfirst.observer.wetter;

public interface AnzeigeElement {
	public void anzeigen();
}
