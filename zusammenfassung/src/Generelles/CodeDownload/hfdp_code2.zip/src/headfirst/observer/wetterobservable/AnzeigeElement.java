package headfirst.observer.wetterobservable;

public interface AnzeigeElement {
	public void anzeigen();
}
