package headfirst.state.kaugummizustandgewinn;

public class KaugummiAutomatTestlauf {

	public static void main(String[] args) {
		KaugummiAutomat kaugummiAutomat = 
			new KaugummiAutomat(10);

		System.out.println(kaugummiAutomat);

		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();
		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();

		System.out.println(kaugummiAutomat);

		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();
		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();

		System.out.println(kaugummiAutomat);

		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();
		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();

		System.out.println(kaugummiAutomat);

		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();
		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();

		System.out.println(kaugummiAutomat);

		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();
		kaugummiAutomat.m�nzeEinwerfen();
		kaugummiAutomat.griffDrehen();

		System.out.println(kaugummiAutomat);
	}
}
