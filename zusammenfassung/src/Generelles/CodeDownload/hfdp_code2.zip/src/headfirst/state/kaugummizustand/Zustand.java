package headfirst.state.kaugummizustand;

public interface Zustand {
 
	public void m�nzeEinwerfen();
	public void m�nzeAuswerfen();
	public void griffDrehen();
	public void kugelAusgeben();
}
