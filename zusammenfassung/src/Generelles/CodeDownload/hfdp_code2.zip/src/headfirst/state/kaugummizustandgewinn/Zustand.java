package headfirst.state.kaugummizustandgewinn;

public interface Zustand {
 
	public void m�nzeEinwerfen();
	public void m�nzeAuswerfen();
	public void griffDrehen();
	public void kugelAuswerfen();
}
