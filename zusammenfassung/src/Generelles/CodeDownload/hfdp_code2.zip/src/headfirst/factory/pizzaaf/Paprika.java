package headfirst.factory.pizzaaf;

public class Paprika implements Gemuese {

	public String toString() {
		return "Rote Paprika";
	}
}
