package headfirst.factory.pizzaaf;

public class FrischeKrabben implements Krabben {

	public String toString() {
		return "Frisch Nordsee-Krabben";
	}
}
