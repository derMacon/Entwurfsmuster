package headfirst.factory.pizzas;

public class KrabbenPizza extends Pizza {
	public KrabbenPizza() {
		name = "Krabben-Pizza";
		teig = "D�nne Kruste";
		so�e = "Wei�e Knoblauchso�e";
		bel�ge.add("Krabben");
		bel�ge.add("Geriebener Parmesan");
	}
}
