package headfirst.factory.pizzaaf;

public class Mozzarella implements Kaese {

	public String toString() {
		return "Mozzarella";
	}
}
