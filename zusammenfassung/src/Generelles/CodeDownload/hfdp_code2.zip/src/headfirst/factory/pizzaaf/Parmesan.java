package headfirst.factory.pizzaaf;

public class Parmesan implements Kaese {

	public String toString() {
		return "Parmesan";
	}
}
