package headfirst.factory.pizzaaf;

public class TeigMitDickerKruste implements Teig {
	public String toString() {
		return "Teig mit extra fester Kruste";
	}
}
