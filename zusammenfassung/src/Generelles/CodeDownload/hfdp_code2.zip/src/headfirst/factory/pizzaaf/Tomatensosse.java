package headfirst.factory.pizzaaf;

public class Tomatensosse implements Sosse {
	public String toString() {
		return "Tomatenso�e";
	}
}
