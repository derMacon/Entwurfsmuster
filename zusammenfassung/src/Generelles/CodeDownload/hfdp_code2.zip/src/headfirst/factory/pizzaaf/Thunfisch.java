package headfirst.factory.pizzaaf;

public interface Thunfisch {
	public String toString();
}
