package headfirst.factory.pizzaaf;

public class SchwarzeOliven implements Gemuese {

	public String toString() {
		return "Schwarze Oliven";
	}
}
