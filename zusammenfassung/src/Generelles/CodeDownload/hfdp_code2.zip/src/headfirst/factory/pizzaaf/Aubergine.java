package headfirst.factory.pizzaaf;

public class Aubergine implements Gemuese {

	public String toString() {
		return "Aubergine";
	}
}
