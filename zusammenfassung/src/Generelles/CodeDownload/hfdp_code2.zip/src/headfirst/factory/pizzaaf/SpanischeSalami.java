package headfirst.factory.pizzaaf;

public class SpanischeSalami implements Salami {
	public String toString() {
		return "Scharfe spanische Salami";
	}
}
