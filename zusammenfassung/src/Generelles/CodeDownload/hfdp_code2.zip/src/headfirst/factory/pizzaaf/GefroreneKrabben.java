package headfirst.factory.pizzaaf;

public class GefroreneKrabben implements Krabben {

	public String toString() {
		return "Gefrorene Gr�nland-Krabben";
	}
}
