package headfirst.factory.pizzaaf;

public interface Gemuese {
	public String toString();
}
