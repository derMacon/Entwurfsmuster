package headfirst.factory.pizzafm;

public class BerlinerSalamiPizza extends Pizza {

	public BerlinerSalamiPizza() { 
		name = "Salami-Pizza Berliner Art";
		teig = "Teig mit fester Kruste";
		so�e = "Marinara-So�e";
 
		bel�ge.add("Geriebener Parmesan");
		bel�ge.add("Salami in Scheiben");
	}
}
