package headfirst.factory.pizzaaf;

public class TeigMitDuennerKruste implements Teig {
	public String toString() {
		return "Teig mit d�nner Kruste";
	}
}
