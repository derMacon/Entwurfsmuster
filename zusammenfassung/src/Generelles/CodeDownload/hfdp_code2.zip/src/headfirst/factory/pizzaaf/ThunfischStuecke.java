package headfirst.factory.pizzaaf;

public class ThunfischStuecke implements Thunfisch {

	public String toString() {
		return "Feine Thunfischst�cke";
	}
}
