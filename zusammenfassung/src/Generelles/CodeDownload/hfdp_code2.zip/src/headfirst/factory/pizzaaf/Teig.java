package headfirst.factory.pizzaaf;

public interface Teig {
	public String toString();
}
