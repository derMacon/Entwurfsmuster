package headfirst.factory.pizzaaf;

public interface Sosse {
	public String toString();
}
