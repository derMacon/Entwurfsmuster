package headfirst.factory.pizzaaf;

public class Pilze implements Gemuese {

	public String toString() {
		return "Pilze";
	}
}
