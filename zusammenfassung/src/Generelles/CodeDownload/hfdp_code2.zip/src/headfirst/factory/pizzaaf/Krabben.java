package headfirst.factory.pizzaaf;

public interface Krabben {
	public String toString();
}
