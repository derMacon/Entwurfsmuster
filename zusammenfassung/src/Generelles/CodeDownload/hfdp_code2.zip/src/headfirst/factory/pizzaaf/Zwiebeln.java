package headfirst.factory.pizzaaf;

public class Zwiebeln implements Gemuese {

	public String toString() {
		return "Zwiebeln";
	}
}
