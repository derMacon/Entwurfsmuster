package headfirst.factory.pizzaaf;

public interface Kaese {
	public String toString();
}
