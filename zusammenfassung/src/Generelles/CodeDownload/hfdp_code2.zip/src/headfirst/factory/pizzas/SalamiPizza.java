package headfirst.factory.pizzas;

public class SalamiPizza extends Pizza {
	public SalamiPizza() {
		name = "Salami-Pizza";
		teig = "Normale Kruste";
		so�e = "Marinara-So�e";
		bel�ge.add("Salami");
		bel�ge.add("Parmesan");
	}
}
