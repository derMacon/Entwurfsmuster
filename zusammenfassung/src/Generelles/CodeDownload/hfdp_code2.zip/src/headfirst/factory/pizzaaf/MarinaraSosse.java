package headfirst.factory.pizzaaf;

public class MarinaraSosse implements Sosse {
	public String toString() {
		return "Marinara-So�e";
	}
}
