package headfirst.factory.pizzaaf;

public class ItalienischeSalami implements Salami {
	public String toString() {
		return "Italienische Salami";
	}
}
