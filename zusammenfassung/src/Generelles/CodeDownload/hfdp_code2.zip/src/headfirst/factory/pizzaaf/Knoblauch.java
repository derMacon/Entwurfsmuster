package headfirst.factory.pizzaaf;

public class Knoblauch implements Gemuese {

	public String toString() {
		return "Knoblauch";
	}
}
