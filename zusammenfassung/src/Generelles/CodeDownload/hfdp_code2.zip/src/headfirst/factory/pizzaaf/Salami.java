package headfirst.factory.pizzaaf;

public interface Salami {
	public String toString();
}
