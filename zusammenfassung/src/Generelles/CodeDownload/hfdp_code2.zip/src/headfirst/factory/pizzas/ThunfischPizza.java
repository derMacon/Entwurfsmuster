package headfirst.factory.pizzas;

public class ThunfischPizza extends Pizza {
	public ThunfischPizza() {
		name = "Thunfisch-Pizza";
		teig = "Kruste";
		so�e = "Marinara-So�e";
		bel�ge.add("Thunfisch");
		bel�ge.add("Oliven");
		bel�ge.add("Kapern");
		bel�ge.add("Geriebener Parmesan");
	}
}
