package headfirst.factory.pizzaaf;

public class Spinat implements Gemuese {

	public String toString() {
		return "Spinat";
	}
}
