package headfirst.iterator.uebergang;

import java.util.Iterator;

public interface Speisekarte {
	public Iterator createIterator();
}
