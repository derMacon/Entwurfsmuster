package headfirst.iterator.restaurantfusion2i;

import java.util.Iterator;

public interface Speisekarte {
	public Iterator createIterator();
}
