package headfirst.iterator.restaurantfusioncafe;

import java.util.Iterator;

public interface Speisekarte {
	public Iterator createIterator();
}
