package headfirst.iterator.restaurantfusion;

public interface Iterator {
	boolean hasNext();
	Object next();
}
