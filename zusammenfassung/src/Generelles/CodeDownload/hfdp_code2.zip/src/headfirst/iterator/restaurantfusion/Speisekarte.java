package headfirst.iterator.restaurantfusion;

public interface Speisekarte {
	public Iterator erstelleIterator();
}
