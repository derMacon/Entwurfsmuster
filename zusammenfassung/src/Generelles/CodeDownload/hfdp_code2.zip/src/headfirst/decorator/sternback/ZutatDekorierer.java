package headfirst.decorator.sternback;

public abstract class ZutatDekorierer extends Getraenk {
	public abstract String getBeschreibung();
}
