package headfirst.decorator.sternback;

public class HausMischung extends Getraenk {
	public HausMischung() {
		beschreibung = "Hausmischung";
	}
 
	public double preis() {
		return .89;
	}
}

