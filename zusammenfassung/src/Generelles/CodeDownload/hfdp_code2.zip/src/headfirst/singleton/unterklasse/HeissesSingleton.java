package headfirst.singleton.unterklasse;

public class HeissesSingleton extends Singleton {
	// n�tzliche Instanzvariablen
 
	private HeissesSingleton() {
		super();
	}
 
	// n�tzliche Methoden
}
