package headfirst.singleton.statisch;

public class SingletonClient {
	public static void main(String[] args) {
		Singleton singleton = Singleton.getInstanz();
	}
}
