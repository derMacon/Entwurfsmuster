package headfirst.adapter.enten;

public interface Truthahn {
	public void kollern();
	public void fliegen();
}
