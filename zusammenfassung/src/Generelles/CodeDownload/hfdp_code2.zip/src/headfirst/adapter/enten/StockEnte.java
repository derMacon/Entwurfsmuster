package headfirst.adapter.enten;

public class StockEnte implements Ente {
	public void quaken() {
		System.out.println("Quack");
	}
 
	public void fliegen() {
		System.out.println("Ich fliege");
	}
}
