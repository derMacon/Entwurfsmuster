package headfirst.adapter.enten;

public interface Ente {
	public void quaken();
	public void fliegen();
}
