package headfirst.adapter.enten;

public class WilderTruthahn implements Truthahn {
	public void kollern() {
		System.out.println("Koller koller");
	}
 
	public void fliegen() {
		System.out.println("Ich fliege nur kurze Strecken");
	}
}
