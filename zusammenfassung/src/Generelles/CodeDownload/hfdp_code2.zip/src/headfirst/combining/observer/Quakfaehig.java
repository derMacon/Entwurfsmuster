package headfirst.combining.observer;

public interface Quakfaehig extends QuakBeobachtungsSubjekt {
	public void quaken();
}
