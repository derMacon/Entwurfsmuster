package headfirst.combining.factory;

public interface Quakfaehig {
	public void quaken();
}
