package headfirst.combining.factory;

public class LockPfeife implements Quakfaehig {
 
	public void quaken() {
		System.out.println("Kwaak");
	}
 
	public String toString() {
		return "Lockpfeife";
	}
}
