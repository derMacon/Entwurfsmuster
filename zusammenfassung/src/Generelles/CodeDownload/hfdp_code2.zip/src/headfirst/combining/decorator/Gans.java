package headfirst.combining.decorator;

public class Gans {
	public void schnattern() {
		System.out.println("Schnatter");
	}

	public String toString() {
		return "Gans";
	}
}
