package headfirst.combining.decorator;

public class GummiEnte implements Quakfaehig {
 
	public void quaken() {
		System.out.println("Quietsch");
	}
  
	public String toString() {
		return "Gummiente";
	}
}
