package headfirst.combining.enten;

public class MoorEnte implements Quakfaehig {
	public void quaken() {
		System.out.println("Quak");
	}
}
