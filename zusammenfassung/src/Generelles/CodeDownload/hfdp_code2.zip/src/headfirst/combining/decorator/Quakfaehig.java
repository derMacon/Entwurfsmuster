package headfirst.combining.decorator;

public interface Quakfaehig {
	public void quaken();
}
