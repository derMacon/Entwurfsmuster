package headfirst.combining.decorator;

public class MoorEnte implements Quakfaehig {
	public void quaken() {
		System.out.println("Quak");
	}
}
