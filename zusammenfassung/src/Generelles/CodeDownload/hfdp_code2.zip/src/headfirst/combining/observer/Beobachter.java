package headfirst.combining.observer;

public interface Beobachter {
	public void aktualisieren(QuakBeobachtungsSubjekt ente);
}
