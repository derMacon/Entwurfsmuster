package headfirst.combining.enten;

public interface Quakfaehig {
	public void quaken();
}
