package headfirst.combining.adapter;

public class Gans {
	public void schnattern() {
		System.out.println("Schnatter");
	}
}
