package headfirst.combining.decorator;

public class StockEnte implements Quakfaehig {
 
	public void quaken() {
		System.out.println("Quak");
	}
 
	public String toString() {
		return "Stockente";
	}
}
