package headfirst.combining.adapter;

public class StockEnte implements Quakfaehig {
	public void quaken() {
		System.out.println("Quak");
	}
}
