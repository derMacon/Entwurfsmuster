package headfirst.combining.adapter;

public interface Quakfaehig {
	public void quaken();
}
