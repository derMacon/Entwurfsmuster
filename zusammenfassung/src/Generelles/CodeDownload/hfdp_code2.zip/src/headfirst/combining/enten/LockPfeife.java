package headfirst.combining.enten;

public class LockPfeife implements Quakfaehig {
	public void quaken() {
		System.out.println("Kwaak");
	}
}
