package headfirst.combining.composite;

public interface Quakfaehig {
	public void quaken();
}
