package headfirst.combining.adapter;

public class GummiEnte implements Quakfaehig {
	public void quaken() {
		System.out.println("Quietsch");
	}
}
