package headfirst.combining.enten;

public class GummiEnte implements Quakfaehig {
	public void quaken() {
		System.out.println("Quietsch");
	}
}
